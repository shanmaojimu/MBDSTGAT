import numpy as np

# 读取保存的权重矩阵
weights = np.loadtxt('time_node_weights.txt')

print("✅ 矩阵维度:", weights.shape)
print(weights[:1, :1])  # 检查前几行
